# SubFam

**Reduce thousands of related sequences to a small alignment of consensus sequences, without choosing an identity threshold.**

SubFam is meant for datasets made of many copies of the same thing that have diverged into internal groups:

- **transposable elements**: all genomic copies of a family (Alu, L1, SINEs, MITEs, …) → its subfamilies
- **satellite DNA**: thousands of monomers → monomer variants and higher-order-repeat units
- **multigene families**: rDNA, histone, tRNA, olfactory receptor copies → paralogous groups

The output is a short alignment (for example 40 rows for 2,000 copies) where every row is the consensus of a group of closely related copies. The private mutations of individual copies are averaged away, and the variants a group shares stay visible. You can read that alignment by eye, build a tree from it, or use it as a library for annotation.

## How it works

```
 2,000 copies         k-mer tree order        chunks of N        chunk consensus       final alignment
 (unordered)    ─►    (similar copies    ─►   neighbours    ─►   (mafft + plurality ─► (mafft L-INS-i)
                       end up adjacent)       N = 50             consensus)
```

1. **Order** all sequences along a k-mer guide tree. The distance between two copies is the weighted Jaccard distance of their k-mer counts (default k = 6). The tree is built by UPGMA, and at every merge the two subtrees are flipped so that their closest ends meet. No alignment is computed in this step, only an order in which related copies sit next to each other. The method is a port of the "Reorder by similarity" guide tree in [ViewAlign](https://github.com/Toki-bio/MSA-viewer) (`kmer-tree.js`). `-m` uses the MAFFT guide tree instead (`mafft --retree 0 --reorder`, as in SubFam 1.0).
2. **Chunk** that order into round(total / *N*) consecutive blocks of equal size (within one sequence), so nothing is dropped and no block is far from *N*.
3. **Consensus**: align each chunk (MAFFT, in parallel) and call its plurality consensus. A base is called when at least `-p` × chunk size of the sequences support it (the residue with the best EDNAFULL column score wins; a gap scores zero, so a column where the residues disagree too much gets no call). Bases supported by half the chunk or fewer are written in lower case. The consensus is EMBOSS `cons` reimplemented in awk (EDNAFULL scores, the same tie rules). Its output is byte-identical to `cons`, which is no longer needed. The default 0.36 is 18 of 50, the plurality SINEderella has used since its first version; `-p` scales it with `-n`.
4. **Align** the chunk consensuses with MAFFT L-INS-i up to 300 consensuses; its pairwise-consistency step with two refinement rounds up to 1,000; MAFFT's automatic mode beyond (the iterative refinement grows with the square of the row count: 6 min at 600 rows, hours at 1,500, for a gain of 0.004 in pairwise identity over the two-round version, measured on 600 B2 consensuses). The rows of `PREFIX.aln.fasta` are in MAFFT's `--reorder` order; `PREFIX.cons.fasta` and `PREFIX.chunks.tsv` are in chunk order.

### Why chunks and not clusters?

Standard tools (CD-HIT, VSEARCH, MMseqs2) build clusters around an **identity threshold**. For repeat families that threshold rarely works:

- **Young families** (copies about 3% from their source): a 95% threshold splits them into hundreds of tiny clusters, and an 80% threshold lumps all subfamilies together.
- **Old families** (copies about 15% from their source, so two copies are about 25–30% apart): any threshold that separates subfamilies leaves most copies as **singletons**.
- The one threshold that does work is different for every family. You can't know it in advance, and you can't apply a single one to a dataset that mixes young and old families.

SubFam never asks "are these two copies X% identical?". It only asks "which copies are each other's nearest neighbours?" and then averages *N* of them. Averaging works at any age: with 50 copies, a consensus recovers the source sequence even when each copy differs from it at 15% of positions. A chunk boundary may still fall inside a subfamily, or straddle two. You then get a few redundant or mixed rows, but each consensus is still exact for the majority of its chunk.

**Choosing N:** the most abundant subfamily dominates every chunk it fills, so a subfamily needs roughly ≥ *N* copies to get its own row. Lower *N* resolves rarer subfamilies at the cost of more rows and noisier consensuses.

## Installation

Requirements: `bash`, `awk` (POSIX; tested with gawk and mawk), [MAFFT](https://mafft.cbrc.jp/alignment/software/) ≥ 7, and, for the k-mer ordering (not needed with `-m`, `-P` or `-I`), a C compiler: `kmer_order.c` (next to `SubFam.sh`) is compiled into the work directory on every run; without a compiler SubFam falls back to an embedded Python script (Python ≥ 3.6 with `numpy` ≥ 1.20; `KMER_IMPL=c|py` forces one). The C and Python versions give byte-identical orders (`tests/test_kmer_order.sh`: 292 synthetic cases). EMBOSS is no longer required. The input may be gzip-compressed. Sequence ids (the first word of a header) must be unique, because `chunks.tsv`, `-e` and `-g` refer to sequences by id; a record without sequence is refused with a message (SubFam never loses a record silently); non-nucleotide input is rejected.

```bash
conda install -c conda-forge -c bioconda mafft numpy
git clone https://github.com/toki-bio/SubFam && cd SubFam
./SubFam.sh -h
```

## Usage

```bash
./SubFam.sh [options] sequences.fasta
```

| option | default | meaning |
|---|---|---|
| `-n INT` | 50 | sequences per chunk (the input is cut into round(total/N) equal chunks) |
| `-p FLOAT` | 0.36 | fraction of a chunk that must support a base to call it |
| `-k INT` | 6 | k-mer size of the ordering tree (3–12) |
| `-t INT` | all cores | threads |
| `-o DIR` | `.` | output directory |
| `-x STR` | input name | output prefix |
| `-r` | off | copies may be on both strands: strand-independent (canonical) k-mers for the tree, then each copy is oriented like its neighbour in the order, and the whole set like its majority strand |
| `-m` | off | order with the MAFFT guide tree instead of k-mers |
| `-I` | off | keep the input order: for input you ordered yourself, or to measure what the ordering contributes (a shuffled input gives the chance level) |
| `-P` | off | order with MAFFT PartTree (implies `-m`), only when the k-mer matrix (~4·n² bytes) does not fit in free memory; SubFam checks this and stops with a message. PartTree chunks are less pure on real data (30,000 Alu copies: 0.400 vs 0.472) |
| `-c` | off | coverage-relative plurality for truncated copies: a base needs `-p` of the sequences that span that column (end gaps excluded, at least 3 spanning), not of the whole chunk |
| `-a` | off | keep no-consensus positions as `N` in `PREFIX.cons.fasta` (by default they are removed, which also removes alignment columns where most of the chunk has a gap); the final alignment never contains them, and SubFam warns when 30 % or more of the positions are `N` |
| `-e LIST` | off | write the original sequences of the listed chunks to one FASTA file each in `PREFIX.chunk_fasta/`; `LIST` is `all` or chunk numbers and ranges, e.g. `3,7,22-45` |
| `-g FILE` | off | your own labels (`id<TAB>group`): report how every chunk is composed by group in `PREFIX.composition.tsv` |
| `-K` | off | keep intermediate chunk files |
| `-F` | off | refine the final alignment on all threads (up to 300 consensuses): faster, but the alignment may differ between runs |

Outputs:

| file | content |
|---|---|
| `PREFIX.cons.fasta` | one consensus per chunk, unaligned |
| `PREFIX.aln.fasta` | the consensuses aligned (FASTA) |
| `PREFIX.msf` | the same alignment in MSF format |
| `PREFIX.chunks.tsv` | `input id`, `consensus`, `strand`: which copy built which consensus |
| `PREFIX.chunkstats.tsv` | per chunk, no labels needed: `n`, `cons_len`, `lower` (share of weakly supported lower-case bases), `core` columns, `agree` (mean share of the sequences that carry the most frequent base of a core column), `id_med` / `id_min` (median / lowest identity of the chunk's sequences to those bases), `ragged` (share of core columns with ≥ 20 % gaps) |
| `PREFIX.chunk_fasta/` (`-e`) | the original sequences of the chosen chunks, input headers and orientation unchanged (`strand` in `chunks.tsv` says which were flipped for the ordering with `-r`) |
| `PREFIX.composition.tsv` (`-g`) | `chunk`, `n`, `labelled`, `majority`, `purity`, then the count of each group |
| `PREFIX.log` | SubFam version, date, command line, input, sequence and chunk count, the settings of the run |

**Chunk names and quality.** A chunk is named `PREFIX_NN` (NN = its position in the k-mer order, so neighbouring numbers are similar). The name carries no quality information, on purpose: names stay stable and safe for downstream tools. Quality is in `PREFIX.chunkstats.tsv`, and, if you supply labels, in `PREFIX.composition.tsv` (`purity`). On the B2 example (60 chunks, 3,000 copies) the five statistics of `chunkstats.tsv` are strongly correlated with each other (Spearman 0.88–0.97) and each correlates with the label purity of the chunk at 0.74; the correlation is 0.80 among the 24 young B2a chunks and only 0.36 among the 36 old ones. So they flag loose chunks, mostly the old, diverged ones, and do not tell a mixed chunk from a merely diverged one (`benchmark/hard/chunk_stats.py` has a prototype for that, with a two-lineage split test, not yet in SubFam).

**Scope.** SubFam orders, chunks, and averages; it does not define groups. `-g` only counts your labels against the chunks and `-e` only gives back the original loci of a chunk. How groups are defined (diagnostic columns, a tree cut, annotation) and how chunks are sorted into them is left to the next step (a diagnostic-column search, a tree cut, or annotation of the rows), applied to `PREFIX.aln.fasta`.

`annotate_aligned_by_ssearch_seqkit.sh` labels the resulting consensuses with their best hit in one or more reference libraries (Dfam, RepBase, your own).

## How SubFam compares to the obvious alternatives

Each of these tools can produce "fewer, representative sequences". The commands below show the closest replacement for SubFam that each one offers:

```bash
# VSEARCH: greedy centroid clustering, with its own built-in consensus output
vsearch --cluster_fast copies.fa --id 0.80 --consout reps.fa --uc clusters.uc

# CD-HIT-EST: greedy clustering; representatives are real copies (centroids)
cd-hit-est -i copies.fa -o reps.fa -c 0.90 -n 8
#   ...and to get consensuses you must align every cluster and call cons yourself
#   (benchmark/cluster_consensus.sh does exactly that)

# MMseqs2: cascaded clustering; representatives are real copies
mmseqs easy-cluster copies.fa reps tmp --min-seq-id 0.90 -c 0.8
```

They differ from SubFam in two ways. First, every one of them needs `--id`/`-c` chosen per dataset. Second, CD-HIT and MMseqs2 return a *real copy* as representative, and a real copy carries all of its own private mutations (about 15% for an old family). The benchmark below measures what that costs.

## Benchmark

`benchmark/` contains a simulator and a script that runs every method on the same input:

```bash
benchmark/run_benchmark.sh bench_out 8      # needs mafft, numpy, emboss (reference consensus for the clustering tools), cd-hit, vsearch, mmseqs2
```

**Simulated families.** Each family starts from a 300 bp ancestor and evolves along a tree into 8 subfamilies. Every branch adds 4 diagnostic substitutions, so sister subfamilies differ at 8 positions (2.7%). The subfamilies have 600, 400, 300, 250, 200, 150, 60 and 40 copies (2,000 in total). Each copy then decays independently from its subfamily source (85% substitutions, 15% short indels) by 3% (young), 8% (middle) or 15% (old). Copies are shuffled and renamed, so no method sees the labels.

**Metrics.** *reps*: number of output sequences. *reps≥10*: those built from at least 10 copies. *singletons*: fraction of copies left alone in a cluster. *median id*: identity of the reps≥10 to the nearest true subfamily source. *recovered*: true subfamilies matched at ≥ 99% identity by a representative whose group is mostly that subfamily.

Each cell shows **subfamilies recovered (of 8)** and, in brackets, **how many representatives** the method produced from 2,000 copies. Full metrics are in [`benchmark/results.tsv`](benchmark/results.tsv).

| method | young (3%) | middle (8%) | old (15%) |
|---|---|---|---|
| **SubFam `-n 50`** (k-mer tree, no threshold) | **8/8** (40) | **8/8** (40) | **7/8** (40) |
| **SubFam `-n 20`** (k-mer tree, no threshold) | **8/8** (100) | **8/8** (100) | **8/8** (100) |
| SubFam `-m -n 50` (MAFFT guide tree) | 8/8 (40) | 8/8 (40) | 7/8 (40) |
| SubFam `-m -n 20` (MAFFT guide tree) | 8/8 (100) | 8/8 (100) | 7/8 (100) |
| VSEARCH `--consout --id 0.95` | 8/8 (1,306) | 0/8 (2,000) | 0/8 (2,000) |
| VSEARCH `--consout --id 0.90` | 8/8 (97) | 1/8 (1,961) | 0/8 (2,000) |
| VSEARCH `--consout --id 0.85` | 6/8 (6) | 8/8 (1,133) | 0/8 (2,000) |
| VSEARCH `--consout --id 0.80` | 0/8 (1) | 8/8 (210) | 0/8 (1,988) |
| VSEARCH `--consout --id 0.75` | 0/8 (1) | 7/8 (15) | 3/8 (1,536) |
| VSEARCH `--consout --id 0.70` | 0/8 (1) | 0/8 (3) | 7/8 (571) |
| VSEARCH `--consout --id 0.65` | 0/8 (1) | 0/8 (2) | 2/8 (73) |
| CD-HIT-EST `-c 0.95` + mafft/cons per cluster | 8/8 (650) | 0/8 (2,000) | 0/8 (2,000) |
| CD-HIT-EST `-c 0.90` + mafft/cons per cluster | 4/8 (10) | 7/8 (1,660) | 0/8 (2,000) |
| CD-HIT-EST `-c 0.80` + mafft/cons per cluster | 0/8 (1) | 6/8 (21) | 4/8 (1,559) |
| CD-HIT-EST centroids, `-c` 0.95 / 0.90 / 0.80 | 0/8 | 0/8 | 0/8 |
| MMseqs2 centroids, `--min-seq-id` 0.95 / 0.90 / 0.80 | ≤ 3/8 | 0/8 | 0/8 |

What the table shows:

- **A threshold that works for one family fails for another.** VSEARCH matches SubFam on each family only inside a narrow window: 0.90 for young, 0.80–0.85 for middle, exactly 0.70 for old. One step outside that window, it either splits the copies into singletons or merges all subfamilies into a single row. A real genome mixes families of every age, so no single `--id` can be right.
- **Even inside that window it is less compact.** On the old family, the best VSEARCH setting needs 571 representatives (16% of copies left as singletons) to reach what SubFam gets with 40.
- **Real copies are bad representatives.** CD-HIT and MMseqs2 centroids never recover a subfamily source. They carry their own mutations: median identity to the true source is 94–98% (young) and as low as 86–90% (middle and old). Building a consensus per cluster fixes this, but only at the cluster sizes the threshold happens to produce.
- **SubFam's consensuses are exact.** Median identity to the true source is 100.0% in all three scenarios. The single miss at `-n 50` is the smallest subfamily (40 copies, below *N*), which merges into its sister subfamily; `-n 20` recovers it. See [Limitations](#limitations).
- **The k-mer tree orders at least as well as MAFFT's.** Chunk purity (fraction of copies whose chunk majority is their own subfamily) is 0.99 / 0.91 / 0.71 for the k-mer tree vs 0.99 / 0.88 / 0.60 for `mafft --retree 0` on the young / middle / old family. k = 5–6 was best at every divergence; k = 3 and k ≥ 10 were clearly worse on the old family.
- **The cost is speed.** SubFam takes 7–17 s on 2,000 × 300 bp (4 cores), versus about 1 s for VSEARCH. Most of it is the per-chunk MAFFT alignments, which are embarrassingly parallel.

## Limitations

- Fixed-size chunks do not follow subfamily boundaries. Expect some redundant rows (an abundant subfamily filling several chunks) and some mixed rows (a chunk straddling two subfamilies). Use `PREFIX.chunks.tsv` to see which copies built each row.
- Subfamilies with fewer than about *N* copies may be absorbed by a neighbour. Lower `-n` if rare variants matter.
- Consensus calling assumes the copies are roughly collinear. Rearranged copies should be filtered. For truncated copies (for example 5′-truncated LINEs) use `-c`, otherwise the consensus is cut down to the region most copies cover; on simulated 5′-truncated copies `-c` recovers full-length consensuses where the default does not. Chunks of very short fragments still make poor rows: discover from long copies, then assign fragments (see docs/SCALING.md).
- The ordering step builds an all-against-all distance matrix of ~4·n² bytes (30,000 sequences: 3.6 GB); SubFam stops when it does not fit in free memory. `-P` (PartTree) needs far less, at a cost in chunk purity.

## Authors

Idea and code: Toki.

## Acknowledgements

Nikita, for ideas at the start of the project, among them aligning the chunks in parallel.

## License

MIT, see [LICENSE](LICENSE).
